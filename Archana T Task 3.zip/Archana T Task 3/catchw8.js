// industry///

$(document).ready(function(){
  $('.industry-slider').slick({          
    infinite: true,        
    speed: 500,            
    slidesToShow: 4,       
    slidesToScroll: 1,     
    autoplay: true,        
    autoplaySpeed: 2000,   
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  });
});

// brand names sliding

$(document).ready(function(){
  $('.brand-slider').slick({
    slidesToShow: 6,  
    slidesToScroll: 1,  
    autoplay: true,  
    autoplaySpeed: 2000,  
    infinite: true, 
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 2
        }
      }
    ]
  });
});

// what we do

$(document).ready(function(){
  $('.what-we-do-slider').slick({
    infinite: true,
    slidesToShow: 1,        
    centerMode: true,        
    centerPadding: '20%',    
    slidesToScroll: 1,
    autoplay: true,          
    autoplaySpeed: 2500,     
    arrows: false,           
    responsive: [
      {
        breakpoint: 1024,    
        settings: {
          slidesToShow: 1,   
          centerPadding: '20%', 
          centerMode: true,  
        }
      },
      {
        breakpoint: 768,    
        settings: {
          slidesToShow: 1,   
          centerMode: false, 
          centerPadding: '20%' 
        }
      },
      {
        breakpoint: 600,    
        settings: {
          slidesToShow: 1,   
          centerMode: false, 
          centerPadding: '20%' 
        }
      }
    ]
  });
});

// owl
$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
      items: 3, 
      margin: 10, 
      nav: true, 
      autoplay: true, 
      autoplayTimeout: 3000, 
      autoplayHoverPause: true, 
  });
});


//  customer slideer
$(document).ready(function(){
  $('.slider').slick({
      infinite: true, 
      speed: 5000, 
      slidesToShow: 1, 
      slidesToScroll: 1, 
      autoplay: true,
      autoplaySpeed: 2000 
  });
});

$(document).ready(function(){
  $('#myModal').modal('show'); 
});


// Show Popup
document.querySelector('[data-popup-target]').addEventListener('click', function() {
  document.getElementById('customPopup').style.display = 'flex';
});

// Close Popup
document.getElementById('closePopup').addEventListener('click', function() {
  document.getElementById('customPopup').style.display = 'none';
});

// Close Popup on Outside Click
window.addEventListener('click', function(event) {
  if (event.target === document.getElementById('customPopup')) {
      document.getElementById('customPopup').style.display = 'none';
  }
});

/// chat
function closeWidget() {
  const chatWidget = document.querySelector('.chat-widget');
  chatWidget.style.display = 'none'; // Hides the widget
}